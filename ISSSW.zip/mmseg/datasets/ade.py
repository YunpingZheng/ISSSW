from .builder import DATASETS
from .custom import CustomDataset


@DATASETS.register_module()
# NYU40Dataset
class ADE20KDataset(CustomDataset):
    """ADE20K dataset.

    In segmentation map annotation for ADE20K, 0 stands for background, which
    is not included in 150 categories. ``reduce_zero_label`` is fixed to True.
    The ``img_suffix`` is fixed to '.jpg' and ``seg_map_suffix`` is fixed to
    '.png'.
    """
    CLASSES = (
        'wall', 'floor', 'cabinet', 'bed', 'chair',
        'sofa', 'table', 'door', 'window', 'bookshelf',
        'picture', 'counter', 'blinds', 'desk', 'shelves', 
        'curtain', 'dresser', 'pillow', 'mirror', 'floor mat',	
        'clothes', 'ceiling', 'books', 'refridgerator', 'television',
        'paper', 'towel', 'shower curtain', 'box', 'whiteboard',
        'person', 'night stand', 'toilet', 'sink', 'lamp', 
        'bathtub', 'bag', 'otherstructure', 'otherfurniture', 'otherprop'
        )

    PALETTE = [(0, 0, 0),
                 (148, 65, 137), (255, 116, 69), (86, 156, 137),
                 (202, 179, 158), (155, 99, 235), (161, 107, 108),
                 (133, 160, 103), (76, 152, 126), (84, 62, 35),
                 (44, 80, 130), (31, 184, 157), (101, 144, 77),
                 (23, 197, 62), (141, 168, 145), (142, 151, 136),
                 (115, 201, 77), (100, 216, 255), (57, 156, 36),
                 (88, 108, 129), (105, 129, 112), (42, 137, 126),
                 (155, 108, 249), (166, 148, 143), (81, 91, 87),
                 (100, 124, 51), (73, 131, 121), (157, 210, 220),
                 (134, 181, 60), (221, 223, 147), (123, 108, 131),
                 (161, 66, 179), (163, 221, 160), (31, 146, 98),
                 (99, 121, 30), (49, 89, 240), (116, 108, 9),
                 (161, 176, 169), (80, 29, 135), (177, 105, 197)
                 ]

    def __init__(self, **kwargs):
        super(ADE20KDataset, self).__init__(
            img_suffix='.png',
            seg_map_suffix='.png',
            reduce_zero_label=True,
            **kwargs)