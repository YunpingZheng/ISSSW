import argparse
import os

import sys

sys.path.append(r'/home/data1/ShiqiangShu/Xuyuan/Swin4INSS')

import cv2
from tqdm import tqdm
import numpy as np


import mmcv
import torch
from mmcv.parallel import MMDataParallel, MMDistributedDataParallel
from mmcv.runner import get_dist_info, init_dist, load_checkpoint
from mmcv.utils import DictAction

from mmseg.apis import multi_gpu_test, single_gpu_test
from mmseg.datasets import build_dataloader, build_dataset
from mmseg.models import build_segmentor
from apply_pcolor import apply_pcolor_on_image



def parse_args():
    parser = argparse.ArgumentParser(
        description='mmseg test (and eval) a model')
    parser.add_argument('config', help='test config file path')
    parser.add_argument('checkpoint',default='./work_dirs/swin_base_3c_NYUDv2/latest.pth', help='checkpoint file')
    parser.add_argument(
        '--aug-test', action='store_true', help='Use Flip and Multi scale aug')
    
    parser.add_argument(
        '--format-only',
        action='store_true',
        default=False,
        help='Format the output results without perform evaluation. It is'
        'useful when you want to format the result to a specific format and '
        'submit it to the test server')
    parser.add_argument(
        '--eval',
        type=str,
        nargs='+',
        help='evaluation metrics, which depends on the dataset, e.g., "mIoU"'
        ' for generic datasets, and "cityscapes" for Cityscapes')
    parser.add_argument('--show', action='store_true', help='show results')
    parser.add_argument(
        '--show-dir', help='directory where painted images will be saved')
    parser.add_argument(
        '--gpu-collect',
        action='store_true',
        help='whether to use gpu to collect results.')
    parser.add_argument(
        '--tmpdir',
        help='tmp directory used for collecting results from multiple '
        'workers, available when gpu_collect is not specified')
    parser.add_argument(
        '--options', nargs='+', action=DictAction, help='custom options')
    parser.add_argument(
        '--gpu-ids',default=4
    )
    parser.add_argument(
        '--eval-options',
        nargs='+',
        action=DictAction,
        help='custom options for evaluation')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='job launcher')
    parser.add_argument('--local_rank', type=int, default=0)
    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)
    return args


def main():
    args = parse_args()

    assert args.eval or args.format_only or args.show \
        or args.show_dir, \
        ('Please specify at least one operation (save/eval/format/show the '
         'results / save the results) with the argument "--out", "--eval"'
         ', "--format-only", "--show" or "--show-dir"')

    if args.eval and args.format_only:
        raise ValueError('--eval and --format_only cannot be both specified')



    cfg = mmcv.Config.fromfile(args.config)
    if args.options is not None:
        cfg.merge_from_dict(args.options)
    # set cudnn_benchmark
    if cfg.get('cudnn_benchmark', False):
        torch.backends.cudnn.benchmark = True
    if args.aug_test:
        # hard code index
        cfg.data.test.pipeline[1].img_ratios = [
            0.5, 0.75, 1.0, 1.25, 1.5, 1.75
        ]
        cfg.data.test.pipeline[1].flip = True
    cfg.model.pretrained = None
    cfg.data.test.test_mode = True

    # init distributed env first, since logger depends on the dist info.
    
    distributed = False

    # build the dataloader
    # TODO: support multiple images per gpu (only minor changes are needed)
    print(cfg.data.test)
    dataset = build_dataset(cfg.data.test)
    
    data_loader = build_dataloader(
        dataset,
        samples_per_gpu=1,
        workers_per_gpu=cfg.data.workers_per_gpu,
        dist=distributed,
        shuffle=False)
    
    filename_list = [item['img_metas'][0].data[0][0]['filename'] for item in data_loader]

    print(filename_list)

    # build the model and load checkpoint
    cfg.model.train_cfg = None
    model = build_segmentor(cfg.model, test_cfg=cfg.get('test_cfg'))
    checkpoint = load_checkpoint(model, args.checkpoint, map_location='cpu')
    model.CLASSES = checkpoint['meta']['CLASSES']
    model.PALETTE = checkpoint['meta']['PALETTE']

    efficient_test = False
    if args.eval_options is not None:
        efficient_test = args.eval_options.get('efficient_test', False)

    model = MMDataParallel(model, device_ids=[5])
    outputs = single_gpu_test(model, data_loader, args.show, args.show_dir,
                                  efficient_test)
    print(outputs[0].shape)
    cv2.imwrite("1.png",outputs[0])
    filename_list = [item['img_metas'][0].data[0][0]['filename'] for item in data_loader]

    

    result_dir = args.checkpoint[:-10]

    save_path = result_dir+'/pcolor_imgs'
    if not os.path.exists(save_path):
        os.mkdir(save_path)
        os.mkdir(save_path+'/gt')
        os.mkdir(save_path+'/pred')
        os.mkdir(save_path+'/result')
        

    def pred2gt(x):
        pred = [1,10,2,8,7,9,0,12,3,4,5,6,11]
        gt = [11,2,3,8,9,4,10,1,5,7,6,0,12]
        return gt[pred.index(x)]

    pred2gt = np.frompyfunc(pred2gt,1,1)

    label_path = './data/nyudv2/nyudv2_label40/'


    for fname,mask in tqdm(zip(filename_list,outputs)):
        img = cv2.imread(fname)   
        pred_mask = mask#pred2gt(mask)
        
        gt_mask = cv2.imread(label_path+fname[-10:],cv2.IMREAD_GRAYSCALE)

        pred_pic = apply_pcolor_on_image(img,pred_mask/40)
        
        gt_pic = apply_pcolor_on_image(img,gt_mask/40)
        
        cv2.imwrite(save_path+'/result/'+fname[-10:],mask)
        cv2.imwrite(save_path+'/gt/'+fname[-10:],gt_pic)
        cv2.imwrite(save_path+'/pred/'+fname[-10:],pred_pic)


    rank, _ = get_dist_info()
    if rank == 0:
        print(f'\nwriting results to {result_dir}/eval_result.pkl')
        mmcv.dump(outputs, result_dir+'/eval_result.pkl')
        kwargs = {} if args.eval_options is None else args.eval_options
        if args.format_only:
            dataset.format_results(outputs, **kwargs)
        if args.eval:
            dataset.evaluate(outputs, args.eval, **kwargs)



if __name__ == '__main__':
    main()
